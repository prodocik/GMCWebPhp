<?php 
//*******Prices********
////Gemini/////
$geminiRegDaily = '$215';
$geminiRegWeekly = '$1,397.50';
$geminiRegMonthly = '$4,472';
$geminiHighDaily = '$225.75';
$geminiHighMonthly = '$1,467.38';
$geminiHighWeekly = '$4,695.60';
$geminiLowDaily = '$193.50';
$geminiLowWeekly = '$1,257.75';
$geminiLowMonthly = '$4,024.80';
$geminiPrepFee = '$95';
////Vegas/////
$vegasRegDaily = '$215';
$vegasRegWeekly = '$1,397.50';
$vegasRegMonthly = '$4,472';
$vegasHighDaily = '$225.75';
$vegasHighWeekly = '$1,467.38';
$vegasHighMonthly = '$4,695.60';
$vegasLowDaily = '$193.50';
$vegasLowWeekly = '$1,257.75';
$vegasLowMonthly = '$4,024.80';
$vegasPrepFee = '$95';
////Cambria/////
$cambriaRegDaily = '$220';
$cambriaRegWeekly = '$1,430';
$cambriaRegMonthly = '$4,576';
$cambriaHighDaily = '$231';
$cambriaHighWeekly = '$1,501.50';
$cambriaHighMonthly = '$4,804.80';
$cambriaLowDaily = '$198';
$cambriaLowWeekly = '$1,287';
$cambriaLowMonthly = '$4,118.40';
$cambriaPrepFee = '$105';
////View/////
$viewRegDaily = '$215';
$viewRegWeekly = '$1,397.50';
$viewRegMonthly = '$4,472';
$viewHighDaily = '$225.75';
$viewHighWeekly = '$1,467.38';
$viewHighMonthly = '$4,695.60';
$viewLowDaily = '$193.50';
$viewLowWeekly = '$1,257.75';
$viewLowMonthly = '$4,024.80';
$viewPrepFee = '$95';
////Lexington/////
$lexRegDaily = '$175';
$lexRegWeekly = '$1,137.50';
$lexRegMonthly = '$3,640';
$lexHighDaily = '$183.75';
$lexHighWeekly = '$1,194.38';
$lexHighMonthly = '$3,822';
$lexLowDaily = '$157.50';
$lexLowWeekly = '$1,023.75';
$lexLowMonthly = '$3,276';
$lexPrepFee = '$95';
////Phoenix/////
$phoenixRegDaily = '$165';
$phoenixRegWeekly = '$1,072.50';
$phoenixRegMonthly = '$3,432';
$phoenixHighDaily = '$173.25';
$phoenixHighWeekly = '$1,126.13';
$phoenixHighMonthly = '$3,603.60';
$phoenixLowDaily = '$148.50';
$phoenixLowWeekly = '$965.25';
$phoenixLowMonthly = '$3,088.80';
$phoenixPrepFee = '$95';
////btcruiser/////
$btcruiserRegDaily = '$165';
$btcruiserRegWeekly = '$1,072.50';
$btcruiserRegMonthly =  '$3,432';
$btcruiserHighDaily = '$173.25';
$btcruiserHighWeekly = '$1,126.13';
$btcruiserHighMonthly =  '$3,603.60';
$btcruiserLowDaily = '$148.50';
$btcruiserLowWeekly = '$965.25';
$btcruiserLowMonthly = '$3,088.80';
$btcruiserPrepFee = '$95';
////Solera/////
$soleraRegDaily = '$185';
$soleraRegWeekly = '$1,202.50';
$soleraRegMonthly = '$3,848';
$soleraHighDaily = '$194.25';
$soleraHighWeekly = '$1,262.63';
$soleraHighMonthly = '$4,040.40';
$soleraLowDaily = '$166.50';
$soleraLowWeekly = '$1,082.25';
$soleraLowMonthly = '$3,463.20';
$soleraPrepFee = '$95';
////Nexus/////
$nexusRegDaily =  '$215';
$nexusRegWeekly = '$1,397.50';
$nexusRegMonthly = '$4,472';
$nexusHighDaily = '$225.75';
$nexusHighWeekly = '$1,467.38';
$nexusHighMonthly = '$4,695.60';
$nexusLowDaily = '$193.50';
$nexusLowWeekly = '$1,257.75';
$nexusLowMonthly = '$4,024.80';
$nexusPrepFee = '$105';
//***************
///PhoneNumber
$phoneNumber = "404-478-6454";
?>

