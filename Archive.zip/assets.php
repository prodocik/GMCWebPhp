<meta name="format-detection" Gasolinecontent="telephone=no">
<meta http-equiv="x-rim-auto-match" content="none">
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="author" content="Georgia Motorcoach" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="https://georgiamotorcoach.com/images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="css/reset.css">
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fonts.css" rel="stylesheet" />
<link href="slick/slick.css" rel="stylesheet" />
<link rel="stylesheet" href="css/faqEngine.css"> <!-- Resource style -->
<link href="css/style.css" rel="stylesheet" />
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="slick/slick.min.js"></script>
<script src="js/modernizr.js"></script> <!-- Modernizr -->

