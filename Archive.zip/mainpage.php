  <div class="container-fluid">
            <div class=" promotext col-lg-12 col-md-12 col-xs-12">
                <h1>GREAT OUTDOOR<big>EXPERIENCE</big></h1>
                  <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3  ">
                  
                    <div class="browseRv" id="btn_book"><a href="ourfleet.html">BROWSE OUR FLEET</a></div>
                </div>
       </div>
        </div>
        
    </header>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-4  advantage">
                    <img src="images/rv.jpg" alt="" width="100" height="100">
                    <p>Popular RV brands</p>
                </div>
                <div class="col-lg-4 advantage">
                    <img src="images/shield.jpg" alt="" width="100" height="100">
                    <p>Full insurance coverage</p>
                </div>
                <div class="col-lg-4 advantage">
                    <img src="images/tfour.jpg" alt="" width="100" height="100">
                    <p>24/7 Road assistance</p>
                </div>
            </div>
        </div>
        <div class="container-fluid orngeline">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 orange_text">
                    <h2>RV Rentals near you</h2>
                    <p>Georgia Motorcoach RV Rental is a small company with a big passion for adventure. We want to help you make memories and deliver unforgettable experiences on board one of our luxury motorhomes. At Georgia Motorcoach RV Rental Company we strive to provide superior service to our customers. We are located just in 15 miles from Atlanta, Georgia</p>
                </div>
            </div>
        </div>
        <div class="container whiteline">
            <div class="col-lg-12 photos-block">
                <img src="images/main_photos/vegas.jpg" alt="vegas">
                <img src="images/main_photos/cambria.jpg" alt="cambria">
                <img src="images/main_photos/gemini.jpg" alt="gemini">
                <img src="images/main_photos/nexus.jpg" alt="nexus">
                <img src="images/main_photos/view.jpg" alt="view">
                <img src="images/main_photos/phoenix.jpg" alt="phoenix">
                <img src="images/main_photos/solera.jpg" alt="solera">
                <img src="images/main_photos/btcruiser.jpg" alt="btcruiser">
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <p>Whant to see all ours motorhomes?</p>
                    <div class="all_rv_listing" id="btn_book"><a href="ourfleet.html">RV LISTING</a></div>
                </div>
            </div>
        </div>
    </div>