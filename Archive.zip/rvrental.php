<!DOCTYPE html>
<html lang="en">
<head>
    <title>Georgia Motorcoach - RV for rent</title>
    <meta name="description" content="Atlanta RV for rent, RV Rentals in Atlanta">
    <meta name="keywords" content="RV Rental, Motorhome Rental, Atlanta, Cobb County, Douglas County, Marietta, Douglasville, Hiram, Lithia Springs, Villa Rica, RV Service, RV Maintenance, RV Storage, Recreational Vehicle Rental, RV rentals, Rent RV, RV trips, Rent Motorhome, RV rentals Atlanta, Motorhome rentals Georgia">
    <?php include ("variables.php");?>
    <?php include ("assets.php");?>
</head>
<body>
	<?php include ("menu.php");?>
    <?php include ("mainMenu.php");?>
    
    <?php include ("func.php");?>
    <?php include ("footer.php");?>
</body>
</html>

