 <div class="mobile-menu">
            <nav>
                <input type="checkbox" id="btn-menu"/>
                <label for="btn-menu"></label>
                <ul class="list-menu">
                <li><a href="../">MAIN</a></li>
                    <li><a href="ourfleet.html">OUR FLEET</a></li>
                     <li><a href="pricing">PRICING</a></li>
                     <li><a href="faq.html">FAQ</a></li>
                    <li><a href="about">ABOUT</a></li>
                    <li><a href="location">LOCATION</a></li>
                </ul>
            </nav>
        </div>
